# Justicia en Cestión
Repositorio de las sesiones de trabajo del grupo de discusión filosófica.

- [Sesión 18 de agosto 2025](sessions/2025-08-18.html)
